$(document).ready(function () {
    $(".likeButton").click(function() {
        $(this).toggleClass("liked");
    });
});