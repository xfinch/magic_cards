<!doctype html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport"
              content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha.4/css/bootstrap.min.css">
        <link rel="stylesheet" href="/css/styles.css">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <title>Document</title>
    </head>
    <body>
        <div class="container">
            <div class="row">
                <header>
                    <h1 class="mtg-header">Magic The Gathering</h1>
                    <div class="form-group">
                        <div class="col-sm-8">
                            <label for="card_search">Search</label>
                            <input type="text" id="card_search">
                        </div>
                        <div class="col-sm-4">
                            <label for="card_filter">Filter</label>
                            <input type="text" class="filter" id="card_filter">
                        </div>
                    </div>
                </header>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="results">

                </div>
            </div>
        </div>
    </body>
    <script>
        var start = 0;
        var limit = 1;
        var reachedMax = false;

        $(window).scroll(function () {
            if ($(window).scrollTop() == $(document).height() - $(window).height())
                getData();
        });

        $(document).ready(function () {
            getData();
        });

        function getData() {
            if (reachedMax)
                return;

            $.ajax({
                url: 'data.php',
                method: 'POST',
                dataType: 'text',
                data: {
                    start: start,
                    limit: limit
                },
                success: function(response) {
                    if (response == "reachedMax") {
                        reachedMax = true;
                    }else {
                        start += limit;
                        $(".results").append(response);
                    }
                }
            });
        }
    </script>
    <script src="/js/likes.js"></script>

</html>
