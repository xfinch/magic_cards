#Magic: The Gathering Custom Plug-in
###by Xavier Finch

####Plug in: Short Code [magic_crds]

Place short code anywhere on a post. See page flow or cards limited by 50 results. 
What's still outstanding with making the infinite scroll work within word press but 
as you can see the infinite scroll works on the proof of concept page. The WordPress 
plugin was built using the TweentySixteen default theme and styled to most suitable for that theme.

To launch proof of concept page:

1) Open Terminal 
2) Navigate to local instance of proof_of_concept index.php (i.e. ```cd ~/Downloads/mtg/proof_of_conept/index.php``` on Mac)
2) enter ```php -S localhost:4000```
3) View page
4) contact me for any questions 817-696-6645 or hirexavier@gmail.com

TODO:: 1) Add function to search and filter. 2) Possible UI change for full page post and page 
templates. 3) Connect a Pro Version of FontAwesome for full use of gliphs(thumbs up icon)