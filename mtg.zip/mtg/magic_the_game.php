<?php

/**
*Plugin Name: Magic: The Gathering
 * Description: A display of Magical Cards for fun and stuff!
 **/
// Method: POST, PUT, GET etc
// Data: array("param" => "value") ==> index.php?param=value
function getCard()
{
    function CallAPI($method, $url, $data = false)
    {
        $curl = curl_init();

        switch ($method)
        {
            case "POST":
                curl_setopt($curl, CURLOPT_POST, 1);

                if ($data)
                    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
                break;
            case "PUT":
                curl_setopt($curl, CURLOPT_PUT, 1);
                break;
            default:
                if ($data)
                    $url = sprintf("%s?%s", $url, http_build_query($data));
        }

// Optional Authentication:
        curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
        curl_setopt($curl, CURLOPT_USERPWD, "username:password");

        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);

        $result = curl_exec($curl);

        curl_close($curl);

        return $result;
    }

    $data = array("types" => "Creature");
    $results = json_decode(CallAPI('GET', 'https://api.magicthegathering.io/v1/cards',$data),TRUE);

    ?>
    <div class="container">
        <div class="row">
            <header>
                <h1 class="mtg-header">Magic: The Gathering</h1>
                <div class="form-group">
                    <div class="col-sm-12">
                        <label for="card_search">Search</label>
                        <input type="text" id="card_search">
                    </div>
                    <div class="col-sm-12">
                        <label for="card_filter">Filter</label>
                        <input type="text" class="filter" id="card_filter">
                    </div>
                </div>
            </header>
        </div>
    </div>
    <?php
    $start = 0;
    foreach($results['cards'] as $card)
    {
        if(isset($card['imageUrl'])){

            ?>

            <div class="container">
                <div class="row">
                    <div class="results">
                        <a class="col-sm-12 col-md-6 col-lg-12 card event">
                            <img src="<?php echo $card['imageUrl'];?>">
                            <div class="content">
                                <h3> <?php echo  $card['name']?></h3>
                                <div class="rollover">
                                    <div> <?php echo 'Artist: ' . $card['artist']?></div>
                                    <div> <?php echo 'From Set: ' . $card['set']?></div>
                                    <div> <?php echo  $card['type'];?> </div>
                                    <button type="button" class="btn btn-secondary" id="like-btn" style="position: relative;
                top: .9rem;"><i class="far fa-thumbs-up"></i>Like</button>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
            <?php
        }
        if(++$start==50) break;
    }
};

add_shortcode('magic_crds','getCard');

function mtg_styles(){
    wp_register_style('mtg-style', plugins_url('/css/styles.css', __FILE__));
    wp_enqueue_style('mtg-style');
    wp_register_style('mtg-fa', plugins_url('/css/fontawesome.min.css', __FILE__));
    wp_enqueue_style('mtg-fa');
    wp_register_style('mtg-style-bootstrap', plugins_url('/css/bootstrap.min.css', __FILE__));
    wp_enqueue_style('mtg-style-bootstrap');
}

add_action('wp_head','mtg_styles');

function mtg_scripts(){
    wp_enqueue_script('jquery');
    wp_register_script('mtg-script', plugins_url('/js/likes.js', __FILE__));
    wp_enqueue_script('mtg-script');
}

add_action('wp_footer', 'mtg_scripts');